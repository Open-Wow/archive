#include "WorldSession.h"


class levelup : public PlayerScript
{
    public:
        levelup() : PlayerScript("levelup") { }

	void OnLevelChanged(Player* player, uint8 oldLevel)
    {
		WorldSession* session = player->GetSession();
        switch (oldLevel)
        {
			case 10:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 10!");
			break;
			case 20:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 20!");
			break;
			case 30:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 30!");
			break;
			case 40:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 40!");
			break;
			case 50:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 50!");
			break;
			case 60:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 60!");
			break;
			case 70:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 70!");
			break;
			case 80:
				player->CastSpell(player, 11305, true);
				player->GetSession()->SendAreaTriggerMessage("Félicitations vous êtes maintenant level 80!");
			break;
		}
    }
};

void AddSC_levelup()
{
    new levelup();
}