#include "ScriptedGossip.h"
#include "ArenaTeam.h"
#include "ArenaTeamMgr.h"

enum spells
{
    POWER_WORD_FORTITUDE = 48162,
    PRAYER_OF_SPRITE = 48074,
    SHADOW_BUFF = 48170,
    KINGS_BUFF = 43223,
    ARCANE_BUFF = 36880,
    MARK_OF_THE_WILD = 48469,
};

class Tools_npc : public CreatureScript
{
public:
    Tools_npc() : CreatureScript("Tools_npc") { }

    struct Tools_npcAI : public ScriptedAI
    {
        Tools_npcAI(Creature* creature) : ScriptedAI(creature) { }

        bool OnGossipHello(Player* player) 
        {
			ClearGossipMenuFor(player);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Buff moi", GOSSIP_SENDER_MAIN, 1);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Restaurer Vie et Mana", GOSSIP_SENDER_MAIN, 2);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Réinitialiser instances", GOSSIP_SENDER_MAIN, 3);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Réinitialiser CD", GOSSIP_SENDER_MAIN, 4);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Réinitialiser combat", GOSSIP_SENDER_MAIN, 5);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Retirer Mal de Résurrection", GOSSIP_SENDER_MAIN, 6);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Réparer", GOSSIP_SENDER_MAIN, 7);
			AddGossipItemFor(player,GOSSIP_ICON_DOT, "Réinitialiser MMR", GOSSIP_SENDER_MAIN, 8);
			SendGossipMenuFor(player, 1, me->GetGUID());
			return true;
        }

        bool OnGossipSelect(Player* player, uint32 menuId, uint32 gossipListId)
        {
			uint32 const sender = player->PlayerTalkClass->GetGossipOptionSender(gossipListId);
            uint32 const action = player->PlayerTalkClass->GetGossipOptionAction(gossipListId);

			ClearGossipMenuFor(player);
			
			if (sender != GOSSIP_SENDER_MAIN)
                return false;			
			
			switch (action)
			{
				case 1:             
					player->CastSpell(player, POWER_WORD_FORTITUDE, true);
					player->CastSpell(player, KINGS_BUFF, true);
					player->CastSpell(player, MARK_OF_THE_WILD, true);
					player->CastSpell(player, PRAYER_OF_SPRITE, true);
					player->CastSpell(player, ARCANE_BUFF, true);
					player->CastSpell(player, SHADOW_BUFF, true);
					me->Whisper("Buff effectué.", LANG_UNIVERSAL, player);
					OnGossipHello(player);
				break;
				case 2:
					if(player->IsInCombat())
					{
						me->Whisper("Vous êtes en combat.", LANG_UNIVERSAL, player);
						CloseGossipMenuFor(player);
					}
					else if(player->GetPowerType() == POWER_MANA)
						player->SetPower(POWER_MANA, player->GetMaxPower(POWER_MANA));
					
					player->SetHealth(player->GetMaxHealth());
					me->Whisper("Wake up!", LANG_UNIVERSAL, player);
					OnGossipHello(player);
				break;
				case 3:
					for (uint8 i = 0; i < MAX_DIFFICULTY; ++i)
					{
						Player::BoundInstancesMap &binds = player->GetBoundInstances(Difficulty(i));
						for (Player::BoundInstancesMap::iterator itr = binds.begin(); itr != binds.end();)
							player->UnbindInstance(itr, Difficulty(i));
					}
					me->Whisper("Instance réinitialisé.", LANG_UNIVERSAL, player);
					OnGossipHello(player);
				break;
				case 4:
					if(player->IsInCombat())
					{
						me->Whisper("Vous êtes en combat.", LANG_UNIVERSAL, player);
						CloseGossipMenuFor(player);
					}
					me->Whisper("Vos CD sont prêts.", LANG_UNIVERSAL, player);
					player->RemoveArenaSpellCooldowns();
					OnGossipHello(player);
				break;
				case 5:
					player->CombatStop();
					me->Whisper("Combat terminé.", LANG_UNIVERSAL, player);
					OnGossipHello(player);
				break;
				case 6:
					if(player->HasAura(15007))
					{
						player->RemoveAura(15007);
						me->Whisper("Mal de résurrection supprimé.", LANG_UNIVERSAL, player);
					}
					OnGossipHello(player);
				break;
				case 7:
					player->DurabilityRepairAll(false, 0, false);
					me->Whisper("Votre équipement à été réparé.", LANG_UNIVERSAL, player);	
					OnGossipHello(player);
				break;
				case 8:
					for(int slot = 0; slot < 3; slot++)
					{
						if(ArenaTeam* team = sArenaTeamMgr->GetArenaTeamById(player->GetArenaTeamId(slot)))
						{
							if(ArenaTeamMember *member = team->GetMember(player->GetGUID()))
							{
								member->ModifyMatchmakerRating(-(int)member->MatchMakerRating,slot);
								me->Whisper("Votre MMR à été remise à zéro.", LANG_UNIVERSAL, player);								
								team->SaveToDB();
							}
						}
					}	
					OnGossipHello(player);
				break;
			}
			return true;
        }
    };

    CreatureAI* GetAI(Creature* creature) const override
    {
        return new Tools_npcAI(creature);
    }
};

void AddSC_Tools_npc()
{
    new Tools_npc();
}