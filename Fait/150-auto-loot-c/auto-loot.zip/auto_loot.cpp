#include "ScriptMgr.h"
#include "Player.h"
#include "Creature.h"
#include "Loot.h"
#include "Group.h"
#include "WorldSession.h"
#include "WorldPacket.h"
 
class AutoLoot : public PlayerScript
{
public: 
    AutoLoot() : PlayerScript("AutoLoot") {}

    void OnCreatureKill(Player* player, Creature* creature) 
	{
        Loot* loot(&creature->loot);
 
        if (!player->GetGroup()) 
		{
            if (player->isAllowedToLoot(creature)) 
			{
                if (!loot->isLooted() && !loot->empty()) 
				{
                    uint32 gold = loot->gold;
                    if (gold > 0) 
					{
                        player->ModifyMoney(gold);
						player->UpdateAchievementCriteria(ACHIEVEMENT_CRITERIA_TYPE_LOOT_MONEY, loot->gold);

						WorldPacket data(SMSG_LOOT_MONEY_NOTIFY, 4 + 1);
						data << uint32(loot->gold);
						data << uint8(1); 
						player->GetSession()->SendPacket(&data);
					}
					
                    uint8 maxSlot = loot->GetMaxSlotInLootFor(player);
                    for (uint32 i = 0; i < maxSlot; ++i) 
					{
                        LootItem* item = loot->LootItemInSlot(i, player);
                        if(player->AddItem(item->itemid, item->count))
						{
							item->is_looted = true;
							player->UpdateAchievementCriteria(ACHIEVEMENT_CRITERIA_TYPE_LOOT_ITEM, item->itemid, item->count);
							player->UpdateAchievementCriteria(ACHIEVEMENT_CRITERIA_TYPE_LOOT_TYPE, loot->loot_type, item->count);
							player->UpdateAchievementCriteria(ACHIEVEMENT_CRITERIA_TYPE_LOOT_EPIC_ITEM, item->itemid, item->count);
						}
						else
							return;
                    }
					
                    loot->clear();
                }
            }
        }
    }
};
 
void AddSC_AutoLoot()
{
    new AutoLoot();
};