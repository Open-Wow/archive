local blacklist = {
    [1] = "cheat",
    [2] = "hack",
    [3] = "bug";
}



local function ChatBlacklist(event, player, msg)
    local gmlevel = player:GetGMRank() -- On obtient le GM Level du compte
    if (gmlevel == 0) then -- Si c'est un joueur

        for i = 1, # blacklist do -- Boucle pour parcourir le tableau des mots interdit
            if (msg.match(msg, blacklist[i])) then -- Si un mot interdit est contenu dans le message

                local mot_interdit = blacklist[i] -- Permet de retenir le mot interdit employé
                local nom_joueur = player:GetName() -- Permet de retenir le nom du joueur qui à dit un mot interdit

                for o, player in ipairs(GetPlayersInWorld()) do -- On obtient tout les joueurs en ligne
                    local pRank = player:GetGMRank() -- On obtient le GM Level du compte du joueur en ligne
                    if pRank ~= 0 then -- Si c'est un membre du staff 
                        player:SendBroadcastMessage("|CFFC41F3BBLACKLIST["..mot_interdit.."]["..nom_joueur.."]: "..msg) -- On lui affiche le message du joueur
                    end                             
                end
            end
        end
    end
end


RegisterPlayerEvent(18, ChatBlacklist) -- Dire
RegisterPlayerEvent(19, ChatBlacklist) -- Chuchote
RegisterPlayerEvent(20, ChatBlacklist) -- Groupe
RegisterPlayerEvent(21, ChatBlacklist) -- Guilde
RegisterPlayerEvent(22, ChatBlacklist) -- Channel
RegisterPlayerEvent(24, ChatBlacklist) -- Emote


-- Réalisé par Kazuma