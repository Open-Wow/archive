# Money_Convertion

# Configuration
1. Open with any Text Editor Money_convertion.lua
2. Ctrl+F Search for 500000 (Gold Coins) and 500002 (Gold Bars) Replace it for your own Item IDS

# Installation
1. Just drop the Money_Convertion.lua in your lua_scripts folder.
2. Install the Platinum_Bars.sql into your characters Database using Navicat or other Programs.
3. Restart the server.
4. Start a new character.
5. Do .mod money 20000000000 and add like 1 more gold for the script to detect the new value into the database.
6. Now you have acces to .transmute command ingame.



# IMPORTANT Note

The script command .transmute is only working if the player reach the gold cap for first time on his character.
You will receive an in-game message telling you how to proceed.
