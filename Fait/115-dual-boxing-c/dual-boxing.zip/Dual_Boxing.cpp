#include "World.h"
#include "WorldSession.h"

class Dual_Boxing : public PlayerScript {
public:
    Dual_Boxing() : PlayerScript("Dual_Boxing") { }
	
    void OnLogin(Player* player, bool /*loginFirst*/)
	{
		//Recherche des connections actives
		SessionMap smap = sWorld->GetAllSessions();
		for (SessionMap::iterator iter = smap.begin(); iter != smap.end(); ++iter)
			if (Player* connect = iter->second->GetPlayer())
				if(player != connect)
					if (player->GetSession()->GetRemoteAddress() == connect->GetSession()->GetRemoteAddress())
					{
						connect->GetSession()->KickPlayer("Dual Boxing");//Kick du joueur déjà connecté
						//player->GetSession()->KickPlayer("Dual Boxing");//Kick du joueur qui veut ce connecter
					}
	}
};

void AddSC_Dual_Boxing()
{
	new Dual_Boxing();
}
