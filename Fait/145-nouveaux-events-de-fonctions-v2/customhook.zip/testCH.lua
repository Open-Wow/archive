local function onAchievementEarned(event, packet, player)
	SendWorldMessage(player:GetName().." à obtenu un haut fait !")
end

local function onCancelLogout(event, packet, player)
	SendWorldMessage(player:GetName().." à interrompu sa déconnexion !")
end

local function onSwim(event, packet, player)
	SendWorldMessage(player:GetName().." commence à nager !")
end

local function onAddFriend(event, packet, player)
	SendWorldMessage(player:GetName().." à ajouter un ami !")
end

Register("onAchievementEarned", onAchievementEarned)
Register("onCancelLogout", onCancelLogout)
Register("onSwim", onSwim)
Register("onAddFriend", onAddFriend)



