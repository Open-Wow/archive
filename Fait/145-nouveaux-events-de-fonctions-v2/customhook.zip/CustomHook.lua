CustomHook = {} ;

CustomHook["onLearn"] = 940
CustomHook["onAchievementEarned"] = 1128
CustomHook["onCancelLogout"] = 78
CustomHook["onRefreshWhoIs"] = 99
CustomHook["onPopFriendList"] = 103
CustomHook["onAddFriend"] = 105
CustomHook["onDelFriend"] = 106
CustomHook["onSetContactNote"] = 107
CustomHook["onAddIgnore"] = 108
CustomHook["onDelIgnore"] = 109
CustomHook["onGroupInvite"] = 111
CustomHook["onGroupAccept"] = 114
CustomHook["onGroupDecline"] = 116
CustomHook["onGroupKick"] = 119 -- Error : Don't work
CustomHook["onSetGroupLead"] = 121 -- Warning : Triggered 2 times
CustomHook["onSwim"] = 202
CustomHook["onStopSwim"] = 203
CustomHook["onInspect"] = 276
CustomHook["onCancelSpell"] = 303
CustomHook["onBuyItem"] = 420
CustomHook["onTagBg"] = 906
--CustomHook["onDismount"] = 940
CustomHook["onMount"] = 366
CustomHook["onSellItem"] = 416



function Register(hookKey, functions)
	if (CustomHook[hookKey] ~= nil ) then
		RegisterPacketEvent(CustomHook[hookKey], 7, functions) 
		RegisterPacketEvent(CustomHook[hookKey], 5, functions)
	else
		print("CustomHook.ext:Register function: Unknown CustomHook key ( "..hookKey.." )")
	end
end


-- Example :
--  Register(CustomHook key table, functionName) 
--  Register("onAchievementEarned", onAchievementEarned)

