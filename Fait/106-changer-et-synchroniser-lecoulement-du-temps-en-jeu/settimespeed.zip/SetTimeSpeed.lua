
local Global = require "GlobalMethods"
local refresh = false

function setGameTimeGlobalOnLogin(_e, player)
    SMSG_LOGIN_SET_TIME_SPEED(player, Global.transformTimeInMin())
end


function refreshTimeGlobal(_e, diff)
    local servTime = GetLocalTime() --(refer to time IRL)
    local hourToRefresh = {0,0}     --(refer to Time in game)

    --reset of var 'refresh' at time 'hourToRefresh' +1 min
    if servTime[1] == hourToRefresh[1] and servTime[2] == (hourToRefresh[2]+1) and refresh then refresh = false end

    if servTime[1] == hourToRefresh[1] and servTime[2] == hourToRefresh[2] and not refresh then

        for i, _player in ipairs(GetPlayersInWorld()) do
            SMSG_LOGIN_SET_TIME_SPEED(_player, Global.transformTimeInMin())
        end

        refresh = true
        return

    else return end
end

--[[create and send -> SMSG_LOGIN_SET_TIME_SPEED = id:0x042, size:12]]--
function SMSG_LOGIN_SET_TIME_SPEED(_player, _time)
    if not _player or not _time then return end

    local SMSG_LSTS = CreatePacket(0x042, 12)
        -- write time in minute : hour * 60 + (coef hour) + min
        -- (time["h"]*60+hourCoeff(time)+time["m"])
        SMSG_LSTS:WriteULong(_time)
        -- default = 0,01666667 (1/60)    (1Day IRL  = 1Day IG)
        --           0,40000008 (1/60*24) (1Hour IRL = 1Day IG)
        SMSG_LSTS:WriteFloat(1/60*24)
        SMSG_LSTS:WriteULong(0)
        _player:SendPacket(SMSG_LSTS)
end

RegisterPlayerEvent(3, setGameTimeGlobalOnLogin)
RegisterServerEvent(13, refreshTimeGlobal)