local Global = {}


--[[GLOBAL METHODS]]


----------------------------------------
-- return time in sec in range [0;1531]
----------------------------------------
function Global.transformTimeInMin()
    local _time = Global.calculateGameTime(GetLocalTime()[1], GetLocalTime()[2])
    return (_time["h"]*60+hourCoeff(_time)+_time["m"])
end

----------------------------------------
-- return time in hour:sec.  eg. 15:28
----------------------------------------
function Global.calculateGameTime(_min, _sec)

    -- Calcul for transform 1 HOUR IRL to 1 DAY In Game --
    local _POAH = _min*100/60 -- Percentage Of An irl's Hour (eg. 45min is 75% of 1 hour)
    local _COTM = 1440*(_POAH)/100 -- Conversion Of 'POAH' to Total Minute in game
    ------------------------------------------------------

    local _time = {}

    _time["h"] = math.floor(_COTM/60)
    _time["m"] = _COTM - (_time["h"]*60) + adjustingMinute(_sec)

    if _time["m"] > 60 and _time["h"] < 24 then _time["h"], _time["m"] = _time["h"]+1, _time["m"]-60 end

    return _time
end


----------------------------------------
-- return true if is day or false otherwise
----------------------------------------
function Global.isDay()
    local _day = {}
    -- set time in minute : hour * 60 + (coef hour) + min
    -- in range [0;1531]
    _day["begin"] = 350 
    _day["end"]   = 1374

    local _timeCalculated = Global.transformTimeInMin()

    if _timeCalculated >= _day["begin"] and _timeCalculated <= _day["end"] then return true
    else return false end
end


--[[OTHER METHODS]]
function adjustingMinute(_sec)
    if _sec > 60 then _sec = 60 end
    return math.floor(_sec*24/60)
end

function hourCoeff(_time)
    local _coef = 0
    
    if _time["m"] == 0 and _time["h"] ~= 0 then _coef = _time["h"]-1
    else _coef = _time["h"] end

    return _coef*4
end

return Global