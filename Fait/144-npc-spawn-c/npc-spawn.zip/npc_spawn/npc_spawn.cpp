#include "ScriptedGossip.h"

enum PNJ
{
	PNJ_1 = 50023,    
	PNJ_2 = 50021,        
};

class npc_spawn : public CreatureScript
{
public:
    npc_spawn() : CreatureScript("npc_spawn") { }

    struct npc_spawnAI : public ScriptedAI
    {
        npc_spawnAI(Creature* creature) : ScriptedAI(creature) { }

        bool OnGossipHello(Player* player) 
        {			
			ClearGossipMenuFor(player);

			if (player->IsInCombat())
			{
				SendGossipMenuFor(player, 1, me->GetGUID());
				me->Whisper("Vous êtes en combat !",LANG_UNIVERSAL,player);
				return false;
			}
			if (player->GetMap()->IsBattlegroundOrArena())
			{
				SendGossipMenuFor(player, 1, me->GetGUID());
				me->Whisper("Vous êtes actuellement en Champs de Bataille !",LANG_UNIVERSAL,player);
				return false;
			}

			AddGossipItemFor(player,GOSSIP_ICON_CHAT, "PNJ_1", GOSSIP_SENDER_MAIN, 2);
			AddGossipItemFor(player,GOSSIP_ICON_CHAT, "PNJ_2", GOSSIP_SENDER_MAIN, 3);
			AddGossipItemFor(player,GOSSIP_ICON_CHAT, "Aurevoir", GOSSIP_SENDER_MAIN, 1);
			SendGossipMenuFor(player, 1, me->GetGUID());
			return true;
        }

        bool OnGossipSelect(Player* player, uint32 menuId, uint32 gossipListId)
        {		
			uint32 const sender = player->PlayerTalkClass->GetGossipOptionSender(gossipListId);
            uint32 const action = player->PlayerTalkClass->GetGossipOptionAction(gossipListId);

			ClearGossipMenuFor(player);
			
			if (sender != GOSSIP_SENDER_MAIN)
                return false;	
			
			switch(action)
			{
				case 1:
						me->Whisper("A la prochaine !",LANG_UNIVERSAL,player);
						SendGossipMenuFor(player, 1, me->GetGUID());
						me->DisappearAndDie();
					break;
				case 2:
						SendGossipMenuFor(player, 1, me->GetGUID());
						player->SummonCreature(PNJ_1,player->GetPositionX() ,player->GetPositionY()+1, player->GetPositionZ(), 0,TEMPSUMMON_TIMED_DESPAWN,30s);
						me->Whisper("PNJ_1 est là, je dois vous dire adieu..",LANG_UNIVERSAL,player);
						me->DisappearAndDie();
						break;
				case 3:
						SendGossipMenuFor(player, 1, me->GetGUID());
						player->SummonCreature(PNJ_2,player->GetPositionX() ,player->GetPositionY()+1, player->GetPositionZ(), 0,TEMPSUMMON_TIMED_DESPAWN,30s);
						me->Whisper("PNJ_2 est là, je dois vous dire adieu..",LANG_UNIVERSAL,player);
						me->DisappearAndDie();
						break;
			}

			return true;
        }
    };

    CreatureAI* GetAI(Creature* creature) const override
    {
        return new npc_spawnAI(creature);
    }
};

void AddSC_npc_spawn()
{
    new npc_spawn();
}