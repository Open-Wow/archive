TrinityAdmin is derived from MangAdmin.
TrinityAdmin v2 was maintained and developed by iotech
TrinityAdmin v2.5 is maintained and developed by SuperStyro

TrinityAdmin also contains code donated by:
Pryd (teleport work)
Gimp (teleport work)
Shocker (various)

Locale Team:
iotech, Ravenheart, Gimp, Dracula70, MrLakeC, Namida, Amok, Lyrr123, borgotech, Morpheux, Georgios, Kitharo

TrinityAdmin(MangAdmin) is developed by:
Josh (Project Owner), iotech, infamousblob, Atreus420, killat200623, dragonfrost, Necroblack and SuperStyro
