#include "ScriptedGossip.h"

class npc_skill : public CreatureScript
{
public:
    npc_skill() : CreatureScript("npc_skill") { }

    struct npc_skillAI : public ScriptedAI
    {
        npc_skillAI(Creature* creature) : ScriptedAI(creature) { }

        bool OnGossipHello(Player* player) 
        {	
			AddGossipItemFor(player,GOSSIP_ICON_CHAT, "> Apprendre mes compétences", GOSSIP_SENDER_MAIN, 1);
			SendGossipMenuFor(player, 1, me->GetGUID());
			return true;
		}


		bool OnGossipSelect(Player* player, uint32 menuId, uint32 gossipListId)
		{
			uint32 const sender = player->PlayerTalkClass->GetGossipOptionSender(gossipListId);
			uint32 const action = player->PlayerTalkClass->GetGossipOptionAction(gossipListId);
			
			ClearGossipMenuFor(player);
				
			if (sender != GOSSIP_SENDER_MAIN)
				return false;
			
			//Double spécialisation
			player->CastSpell(player,63680,true);
			player->CastSpell(player,63624,true);
			
			//Monture
			player->LearnSpell(33388, false);//Apprenti cavalier
			player->LearnSpell(33392, false);//Compagnon cavalier
			player->LearnSpell(34092, false);//Expert cavalier
			player->LearnSpell(34093, false);//Artisan cavalier		
			player->LearnSpell(54197, false);//Vol par temps froid	
			
			switch(player->GetClass())
			{
				case CLASS_WARRIOR:
					//Armes
					player->LearnSpell(1715, false);//Brise-genou
					player->LearnSpell(11578, false);//Charge
					player->LearnSpell(47502, false);//Coup de tonnerre
					player->LearnSpell(694, false);//Coup railleur
					player->LearnSpell(47450, false);//Frappe héroïque
					
					if(player->HasSpell(12294))//Frappe mortelle(Talent)
						player->LearnSpell(47486, false);//Frappe mortelle
					
					player->LearnSpell(7384, false);//Fulgurance
					player->LearnSpell(64382, false);//Lancer fracassant
					player->LearnSpell(57755, false);//Lancer héroïque
					player->LearnSpell(47465, false);//Pourfendre
					player->LearnSpell(20230, false);//Représailles					
					//Fureur
					player->LearnSpell(47440, false);//Cri de commandement
					player->LearnSpell(1161, false);//Cri de défi
					player->LearnSpell(47436, false);//Cri de guerre
					player->LearnSpell(47437, false);//Cri démoralisant
					player->LearnSpell(5246, false);//Cri d’intimidation
					player->LearnSpell(47520, false);//Enchaînement
					player->LearnSpell(47471, false);//Exécution
					player->LearnSpell(47475, false);//Heurtoir
					player->LearnSpell(20252, false);//Interception
					player->LearnSpell(34428, false);//Ivresse de la victoire
					player->LearnSpell(2458, false);//Posture berserker
					player->LearnSpell(18499, false);//Rage berserker
					player->LearnSpell(55694, false);//Régénération enragée					
					player->LearnSpell(1719, false);//Témérité
					player->LearnSpell(1680, false);//Tourbillon
					player->LearnSpell(6552, false);//Volée de coups					
					//Protection
					player->LearnSpell(72, false);//Coup de bouclier
					player->LearnSpell(676, false);//Désarmement
					
					if(player->HasSpell(20243))//Dévaster(Talent)
						player->LearnSpell(47498, false);//Dévaster
					
					player->LearnSpell(7386, false);//Fracasser armure
					player->LearnSpell(47488, false);//Heurt de bouclier
					player->LearnSpell(3411, false);//Intervention
					player->LearnSpell(12678, false);//Maîtrise des postures
					player->LearnSpell(2565, false);//Maîtrise du blocage
					player->LearnSpell(871, false);//Mur protecteur
					player->LearnSpell(71, false);//Posture défensive
					player->LearnSpell(355, false);//Provocation
					player->LearnSpell(2687, false);//Rage sanguinaire
					player->LearnSpell(23920, false);//Renvoi de sort						
					player->LearnSpell(57823, false);//Vengeance							
					//Compétences
					player->LearnSpell(674, false);//Ambidextrie				
					player->LearnSpell(3127, false);//Parade					
					player->LearnSpell(750, false);//Armure en plaques					
					player->LearnSpell(5011, false);//Arbalètes
					player->LearnSpell(264, false);//Arcs
					player->LearnSpell(266, false);//Armes à feu
					player->LearnSpell(200, false);//Armes d'hast
					player->LearnSpell(2567, false);//Armes de jet
					player->LearnSpell(15590, false);//Armes de pugilat
					player->LearnSpell(227, false);//Bâtons
					player->LearnSpell(1180, false);//Dagues
					player->LearnSpell(201, false);//Epées à une main
					player->LearnSpell(202, false);//Epées à deux mains
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(197, false);//Haches à deux mains
					player->LearnSpell(198, false);//Masses à une main
					player->LearnSpell(199, false);//Masses à deux mains
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();				
					player->SaveToDB();
				break;
				case CLASS_PALADIN:
					//Protection
					player->LearnSpell(48942, false);//Aura de dévotion
					player->LearnSpell(48943, false);//Aura de résistance à l'Ombre
					player->LearnSpell(48947, false);//Aura de résistance au Feu
					player->LearnSpell(48945, false);//Aura de résistance au Givre
					player->LearnSpell(20217, false);//Bénédiction des rois
					player->LearnSpell(25898, false);//Bénédiction des rois supérieure
					
					if(player->HasSpell(20911))//Bénédiction du sanctuaire(Talent)
						player->LearnSpell(25899, false);//Bénédiction du sanctuaire supérieure
					
					player->LearnSpell(61411, false);//Bouclier de piété
					player->LearnSpell(642,   false);//Bouclier divin
					
					if(player->HasSpell(31935))//Bouclier du vengeur
						player->LearnSpell(48827, false);//Bouclier du vengeur
						
					if(player->HasSpell(20925))//Bouclier sacré(Talent)				
						player->LearnSpell(48952, false);//Bouclier sacré
					
					player->LearnSpell(31789, false);//Défense vertueuse
					player->LearnSpell(25780, false);//Fureur vertueuse
					player->LearnSpell(19752, false);//Intervention divine
					player->LearnSpell(1044,  false);//Main de liberté
					player->LearnSpell(10278, false);//Main de protection
					player->LearnSpell(62124, false);//Main de rétribution
					player->LearnSpell(6940,  false);//Main de sacrifice
					player->LearnSpell(1038,  false);//Main de salut
					player->LearnSpell(10308, false);//Marteau de la justice
					player->LearnSpell(498,   false);//Protection divine
					player->LearnSpell(20164, false);//Sceau de justice
					//Sacré
					player->LearnSpell(19746, false);//Aura de concentration
					player->LearnSpell(48936, false);//Bénédiction de sagesse
					player->LearnSpell(48938, false);//Bénédiction de sagesse supérieure
					player->LearnSpell(53601, false);//Bouclier saint
					player->LearnSpell(48817, false);//Colère divine
					player->LearnSpell(48819, false);//Consécration
					player->LearnSpell(5502,  false);//Détection des morts-vivants
					player->LearnSpell(48785, false);//Eclair lumineux
					player->LearnSpell(4987,  false);//Epuration
					player->LearnSpell(48801, false);//Exorcisme
					
					if(player->HasSpell(20473))//Horion sacré(Talent)
						player->LearnSpell(48825, false);//Horion sacré
					
					player->LearnSpell(48788, false);//Imposition des mains
					player->LearnSpell(48782, false);//Lumière sacrée
					player->LearnSpell(1152,  false);//Purification
					player->LearnSpell(48950, false);//Rédemption
					player->LearnSpell(10326, false);//Renvoi du mal
					player->LearnSpell(20165, false);//Sceau de lumière
					player->LearnSpell(20166, false);//Sceau de sagesse
					player->LearnSpell(54428, false);//Supplique divine
					//Vindicte
					player->LearnSpell(32223, false);//Aura de croisé
					player->LearnSpell(54043, false);//Aura de vindicte
					player->LearnSpell(48932, false);//Bénédiction de puissance
					player->LearnSpell(48934, false);//Bénédiction de puissance supérieure
					player->LearnSpell(53407, false);//Jugement de justice					
					player->LearnSpell(20271, false);//Jugement de lumière			
					player->LearnSpell(53408, false);//Jugement de sagesse	
					player->LearnSpell(48806, false);//Marteau de courroux
					player->LearnSpell(31884, false);//Courroux vengeur
					
					if(player->GetTeam() == ALLIANCE)
					{
						player->LearnSpell(31801, false);//Sceau de vengeance
						player->LearnSpell(13819, false);//Cheval de guerre
						player->LearnSpell(23214, false);//Destrier
					}
					else
					{
						player->LearnSpell(53736, false);//Sceau de corruption
						player->LearnSpell(34769, false);//Invocation : cheval de guerre
						player->LearnSpell(34767, false);//Invocation : destrier
					}
					//Compétences
					player->LearnSpell(3127, false);//Parade
					player->LearnSpell(750, false);//Armure en plaques
					player->LearnSpell(200, false);//Armes d'hast
					player->LearnSpell(201, false);//Epées à une main
					player->LearnSpell(202, false);//Epées à deux mains
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(197, false);//Haches à deux mains
					player->LearnSpell(198, false);//Masses à une main
					player->LearnSpell(199, false);//Masses à deux mains
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_HUNTER:
					//Maîtrise des bêtes
					player->LearnSpell(62757, false);//Appel d'un familier à l'écurie
					player->LearnSpell(883,   false);//Appel du familier
					player->LearnSpell(53271, false);//Appel du maître
					player->LearnSpell(1515,  false);//Apprivoise une bête
					player->LearnSpell(13161, false);//Aspect de la bête
					player->LearnSpell(13159, false);//Aspect de la meute
					player->LearnSpell(49071, false);//Aspect de la nature
					player->LearnSpell(34074, false);//Aspect de la vipère
					player->LearnSpell(27044, false);//Aspect du faucon
					player->LearnSpell(61847, false);//Aspect du faucon-dragon
					player->LearnSpell(5118,  false);//Aspect du guépard
					player->LearnSpell(13163, false);//Aspect du singe
					player->LearnSpell(1462,  false);//Connaissance des bêtes
					player->LearnSpell(14327, false);//Effrayer une bête
					player->LearnSpell(48990, false);//Guérison du familier
					player->LearnSpell(6991,  false);//Nourrir le familier
					player->LearnSpell(6197,  false);//Oeil d'aigle
					player->LearnSpell(34026, false);//Ordre de tuer
					player->LearnSpell(2641,  false);//Renvoyer le familier
					player->LearnSpell(982,   false);//Ressusciter le familier
					player->LearnSpell(1002,  false);//Yeux de la bête					
					//Précision
					player->LearnSpell(49048, false);//Flèches multiples
					player->LearnSpell(1543,  false);//Fusée éclairante
					player->LearnSpell(53338, false);//Marque du chasseur
					player->LearnSpell(49001, false);//Morsure de serpent
					player->LearnSpell(3034,  false);//Morsure de vipère
					player->LearnSpell(3043, false);//Piqûre de scorpide
					player->LearnSpell(58434, false);//Salve
					player->LearnSpell(49052, false);//Tir assuré
					player->LearnSpell(49045, false);//Tir des arcanes
					player->LearnSpell(61006, false);//Tir mortel	
					player->LearnSpell(3045,  false);//Tir rapide
					player->LearnSpell(19801, false);//Tir tranquillisant	
					player->LearnSpell(5116,  false);//Trait de choc
					player->LearnSpell(20736, false);//Trait provocateur
					
					if(player->HasSpell(19434))//Visée(Talent)			
						player->LearnSpell(49050, false);//Visée
					
					//Survie
					player->LearnSpell(48996, false);//Attaque du raptor
					
					if(player->HasSpell(19306))//Contre-attaque(Talent)
						player->LearnSpell(48999, false);//Contre-attaque
					
					player->LearnSpell(2974,  false);//Coupure d'ailes
					player->LearnSpell(781,   false);//Désengagement
					player->LearnSpell(34477, false);//Détournement
					player->LearnSpell(19263, false);//Dissuasion
					player->LearnSpell(5384,  false);//Feindre la mort
					player->LearnSpell(60192, false);//Flèche givrante		
					player->LearnSpell(53339, false);//Morsure de la mangouste
					player->LearnSpell(34600, false);//Piège à serpent
					player->LearnSpell(1494,  false);//Pistage des bêtes					
					player->LearnSpell(49056, false);//Piège d'immolation
					player->LearnSpell(13809, false);//Piège de givre
					player->LearnSpell(49067, false);//Piège explosif
					player->LearnSpell(14311, false);//Piège givrant
					
					if(player->HasSpell(19386))//Piqûre de wyverne(Talent)
						player->LearnSpell(49012, false);//Piqûre de wyverne
					
					player->LearnSpell(19885, false);//Pistage des camouflés
					player->LearnSpell(19878, false);//Pistage des démons
					player->LearnSpell(19879, false);//Pistage des draconiens
					player->LearnSpell(19880, false);//Pistage des élémentaires
					player->LearnSpell(19883, false);//Pistage des humanoïdes
					player->LearnSpell(19882, false);//Pistage des géants
					player->LearnSpell(19884, false);//Pistage des morts-vivants
					
					if(player->HasSpell(53301))//Tir explosif(Talent)
						player->LearnSpell(60053, false);//Tir explosif	
					
					//Compétences
					player->LearnSpell(3127, false);//Parade
					player->LearnSpell(674, false);//Ambidextrie
					player->LearnSpell(8737, false);//Mailles
					player->LearnSpell(5011, false);//Arbalètes
					player->LearnSpell(264, false);//Arcs
					player->LearnSpell(266, false);//Armes à feu
					player->LearnSpell(200, false);//Armes d'hast
					player->LearnSpell(2567, false);//Armes de jet
					player->LearnSpell(15590, false);//Armes de pugilat
					player->LearnSpell(227,  false);//Bâtons
					player->LearnSpell(1180, false);//Dagues
					player->LearnSpell(201, false);//Epées à une main
					player->LearnSpell(202, false);//Epées à deux mains
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(197, false);//Haches à deux mains	
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_MAGE:
					//Arcanes
					player->LearnSpell(43017, false);//Amplification de la magie
					player->LearnSpell(43024, false);//Armure du mage
					player->LearnSpell(43015, false);//Atténuation de la magie

					if(player->HasSpell(44425))//Barrage des arcanes(Talent)
						player->LearnSpell(44781, false);//Barrage des arcanes
					
					player->LearnSpell(43020, false);//Bouclier de mana
					player->LearnSpell(130,	  false);//Chute lente
					player->LearnSpell(2139,  false);//Contresort
					player->LearnSpell(475,   false);//Délivrance de la malédiction
					player->LearnSpell(42897, false);//Déflagration des arcanes
					player->LearnSpell(12051, false);//Evocation
					player->LearnSpell(42921, false);//Explosion des arcanes
					player->LearnSpell(61316, false);//Illumination de Dalaran
					player->LearnSpell(43002, false);//Illumination des arcanes	
					player->LearnSpell(55342, false);//Image miroir
					player->LearnSpell(61024, false);//Intelligence de Dalaran
					player->LearnSpell(42995, false);//Intelligence des arcanes
					player->LearnSpell(66,    false);//Invisibilité 
					player->LearnSpell(27090, false);//Invocation d'eau
					player->LearnSpell(42985, false);//Invocation d'une gemme de mana
					player->LearnSpell(33717, false);//Invocation de nourriture
					player->LearnSpell(42956, false);//Invocation de rafraîchissements					
					player->LearnSpell(12826, false);//Métamorphose(Mouton)
					player->LearnSpell(28271, false);//Métamorphose(Tortue)
					player->LearnSpell(61780, false);//Métamorphose(Dinde)
					player->LearnSpell(61721, false);//Métamorphose(Lapin)
					player->LearnSpell(28272, false);//Métamorphose(Cochon)				
					player->LearnSpell(53140, false);//Téléportation : Dalaran
					player->LearnSpell(53142, false);//Portail : Dalaran
					
					if(player->GetTeam() == ALLIANCE)
					{
						player->LearnSpell(32271, false);//Téléportation : Exodar
						player->LearnSpell(49359, false);//Téléportation : Theramore
						player->LearnSpell(3565,  false);//Téléportation : Darnassus
						player->LearnSpell(33690, false);//Téléportation : Shattrath
						player->LearnSpell(3562,  false);//Téléportation : Forgefer
						player->LearnSpell(3561,  false);//Téléportation : Hurlevent
						player->LearnSpell(11419, false);//Portail : Darnassus
						player->LearnSpell(32266, false);//Portail : Exodar
						player->LearnSpell(11416, false);//Portail : Forgefer
						player->LearnSpell(33691, false);//Portail : Shattrath
						player->LearnSpell(49360, false);//Portail : Theramore
						player->LearnSpell(10059, false);//Portail : Hurlevent
					}
					else
					{
						player->LearnSpell(3567,  false);//Téléportation : Orgrimmar
						player->LearnSpell(35715, false);//Téléportation : Shattrath
						player->LearnSpell(3566,  false);//Téléportation : les Pitons du Tonnerre
						player->LearnSpell(49358, false);//Téléportation : Pierrêche
						player->LearnSpell(32272, false);//Téléportation : Lune-d'argent
						player->LearnSpell(3563,  false);//Téléportation : Fossoyeuse
						player->LearnSpell(11417, false);//Portail : Orgrimmar
						player->LearnSpell(35717, false);//Portail : Shattrath
						player->LearnSpell(32267, false);//Portail : Lune-d'argent
						player->LearnSpell(49361, false);//Portail : Pierrêche
						player->LearnSpell(11420, false);//Portail : les Pitons du Tonnerre
						player->LearnSpell(11418, false);//Portail : Fossoyeuse
					}
					
					player->LearnSpell(42846, false);//Projectiles des arcanes
					player->LearnSpell(58659, false);//Rituel des rafraîchissements
					player->LearnSpell(1953,  false);//Transfert
					player->LearnSpell(30449, false);//Vol de sort
					//Feu
					player->LearnSpell(43046, false);//Armure de la fournaise
					
					if(player->HasSpell(44457))//Bombe vivante(Talent)
						player->LearnSpell(55360, false);//Bombe vivante
					
					player->LearnSpell(42833, false);//Boule de feu
					player->LearnSpell(42859, false);//Brûlure
					player->LearnSpell(42926, false);//Choc de flammes
					player->LearnSpell(47610, false);//Eclair de givrefeu
					
					if(player->HasSpell(11366))//Explosion pyrotechnique(Talent)
						player->LearnSpell(42891, false);//Explosion pyrotechnique
					
					player->LearnSpell(43010, false);//Gardien de feu
					
					if(player->HasSpell(31661))//Souffle du dragon(Talent)				
						player->LearnSpell(42950, false);//Souffle du dragon
					
					player->LearnSpell(42873, false);//Trait de feu
					
					if(player->HasSpell(11113))//Vague explosive(Talent)
						player->LearnSpell(42945, false);//Vague explosive
					
					//Givre
					player->LearnSpell(7301,  false);//Armure de givre
					player->LearnSpell(43008, false);//Armure de glace

					if(player->HasSpell(11426))//Barrière de glace(Talent)
						player->LearnSpell(43039, false);//Barrière de glace
					
					player->LearnSpell(42940, false);//Blizzard
					player->LearnSpell(45438, false);//Bloc de glace
					player->LearnSpell(42931, false);//Cône de froid
					player->LearnSpell(42842, false);//Eclair de givre
					player->LearnSpell(43012, false);//Gardien de givre					
					player->LearnSpell(42914, false);//Javelot de glace
					player->LearnSpell(42917, false);//Nova de givre		
					//Compétences
					player->LearnSpell(227,  false);//Bâtons
					player->LearnSpell(1180, false);//Dagues					
					player->LearnSpell(201,  false);//Epées à une main
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_WARLOCK:
					//Affliction
					if(player->HasSpell(30108))//Affliction instable(Talent)
						player->LearnSpell(47843, false);//Affliction instable
					
					player->LearnSpell(57946, false);//Connexion
					player->LearnSpell(47813, false);//Corruption
					player->LearnSpell(47855, false);//Drain d'âme
					player->LearnSpell(5138, false);//Drain de mana
					player->LearnSpell(47857, false);//Drain de vie
					player->LearnSpell(47836, false);//Graine de Corruption
					
					if(player->HasSpell(48181))//Hanter(Talent)
						player->LearnSpell(59164, false);//59164
					
					player->LearnSpell(17928, false);//Hurlement de terreur	
					player->LearnSpell(47864, false);//Malédiction d'agonie
					player->LearnSpell(50511, false);//Malédiction de faiblesse	
					player->LearnSpell(47865, false);//Malédiction des éléments
					player->LearnSpell(11719, false);//Malédiction des langages
					player->LearnSpell(47867, false);//Malédiction funeste
					
					if(player->HasSpell(18220))//Pacte noir(Talent)
						player->LearnSpell(59092, false);//Pacte noir
					
					player->LearnSpell(6215, false);//Peur
					player->LearnSpell(47860, false);//Voile mortel					
					//Démonologie
					player->LearnSpell(47889, false);//Armure démoniaque
					player->LearnSpell(61191, false);//Asservir démon
					player->LearnSpell(18647, false);//Bannir
					player->LearnSpell(29858, false);//Brise-âme
					player->LearnSpell(47856, false);//Captation de vie	
					player->LearnSpell(48018, false);//Cercle démoniaque : Invocation
					player->LearnSpell(48020, false);//Cercle démoniaque : Téléportation
					player->LearnSpell(47884, false);//Création de pierre d'âme
					player->LearnSpell(60220, false);//Création de pierre de feu
					player->LearnSpell(47878, false);//Création de pierre de soins
					player->LearnSpell(47888, false);//Création de pierre de sort
					player->LearnSpell(132, false);//Détection de l'invisibilité
					player->LearnSpell(5500, false);//Détection des démons
					player->LearnSpell(47893, false);//Gangrarmure
					player->LearnSpell(47891, false);//Gardien de l'ombre
					player->LearnSpell(1122, false);//Inferno
					player->LearnSpell(691, false);//Invocation : chasseur corrompu	
					player->LearnSpell(688, false);//Invocation : diablotin
					player->LearnSpell(697, false);//Invocation : marcheur du Vide
					player->LearnSpell(712, false);//Invocation : succube
					player->LearnSpell(126, false);//Oeil de Kilrogg
					player->LearnSpell(696, false);//Peau de démon
					player->LearnSpell(5697, false);//Respiration interminable
					player->LearnSpell(698, false);//Rituel d'invocation
					player->LearnSpell(18540, false);//Rituel de malédiction
					player->LearnSpell(58887, false);//Rituel des âmes
					//Destruction
					if(player->HasSpell(17877))//Brûlure de l'ombre(Talent)					
						player->LearnSpell(47827, false);//Brûlure de l'ombre
					
					player->LearnSpell(47815, false);//Douleur brûlante
					player->LearnSpell(47825, false);//Feu de l'âme
					player->LearnSpell(47823, false);//Flammes infernales
					
					if(player->HasSpell(30283))//Furie de l'ombre(talent)
						player->LearnSpell(47847, false);//Furie de l'ombre
					
					player->LearnSpell(47811, false);//Immolation
					player->LearnSpell(47838, false);//Incinérer
					player->LearnSpell(61290, false);//Ombreflamme
					player->LearnSpell(47820, false);//Pluie de feu
					player->LearnSpell(47809, false);//Trait de l'ombre
					
					if(player->HasSpell(50796))//Trait du chaos(Talent)
						player->LearnSpell(59172, false);//Trait du chaos
					
					//Compétences
					player->LearnSpell(23161, false);//Destrier de l'effroi
					player->LearnSpell(227,  false);//Bâtons
					player->LearnSpell(1180, false);//Dagues					
					player->LearnSpell(201,  false);//Epées à une main
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_ROGUE:
					//Assassinat
					player->LearnSpell(8643, false);//Aiguillon perfide
					player->LearnSpell(1833, false);//Coup bas
					player->LearnSpell(6774, false);//Débiter
					player->LearnSpell(51722, false);//Démantèlement
					player->LearnSpell(48691, false);//Embuscade
					player->LearnSpell(57993, false);//Envenimer

					if(player->HasSpell(1329))//Estropier(Talent)
						player->LearnSpell(48666, false);//Estropier
					
					player->LearnSpell(48668, false);//Eviscération
					player->LearnSpell(8647, false);//Exposer l'armure
					player->LearnSpell(48676, false);//Garrot
					player->LearnSpell(48674, false);//Lancer mortel
					player->LearnSpell(48672, false);//Rupture
					//Combat
					player->LearnSpell(48638, false);//Attaque pernicieuse					
					player->LearnSpell(48657, false);//Attaque sournoise
					player->LearnSpell(1766, false);//Coup de pied	
					player->LearnSpell(26669, false);//Evasion
					player->LearnSpell(51723, false);//Eventail de couteaux
					player->LearnSpell(48659, false);//Feinte
					player->LearnSpell(5938, false);//Kriss
					player->LearnSpell(11305, false);//Sprint
					player->LearnSpell(1776, false);//Suriner
					//Finesse
					player->LearnSpell(51724, false);//Assommer						
					player->LearnSpell(1784, false);//Camouflage
					player->LearnSpell(31224, false);//Cape d'ombre		
					player->LearnSpell(2094, false);//Cécité
					player->LearnSpell(1860, false);//Chute amortie	
					player->LearnSpell(1842, false);//Désarmement de piège		
					player->LearnSpell(2836, false);//Détection des pièges
					player->LearnSpell(26889, false);//Disparition
					player->LearnSpell(1725, false);//Distraction	
					player->LearnSpell(57934, false);//Ficelles du métier	
					
					if(player->HasSpell(16511))//Hémorragie(Talent)
						player->LearnSpell(48660, false);//Hémorragie
					
					player->LearnSpell(921, false);//Vol à la tire
					//Compétences
					player->LearnSpell(674, false);//Ambidextrie
					player->LearnSpell(1804, false);//Crochetage
					player->LearnSpell(3127, false);//Parade
					player->LearnSpell(5011, false);//Arbalètes
					player->LearnSpell(264, false);//Arcs
					player->LearnSpell(266, false);//Armes à feu
					player->LearnSpell(2567, false);//Armes de jet
					player->LearnSpell(15590, false);//Armes de pugilat
					player->LearnSpell(1180, false);//Dagues
					player->LearnSpell(201, false);//Epées à une main
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(198, false);//Masses à une main				
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_PRIEST:
					//Discipline
					player->LearnSpell(8129, false);//Brûlure de mana
					player->LearnSpell(988, false);//Dissipation de la magie
					player->LearnSpell(32375, false);//Dissipation de masse
					player->LearnSpell(10955, false);//Entraves des morts-vivants
					player->LearnSpell(48073, false);//Esprit divin
					player->LearnSpell(48168, false);//Feu intérieur
					player->LearnSpell(6346, false);//Gardien de peur
					player->LearnSpell(1706, false);//Lévitation
					player->LearnSpell(48066, false);//Mot de pouvoir : Bouclier
					player->LearnSpell(48161, false);//Mot de pouvoir : Robustesse
					
					if(player->HasSpell(47540))//Pénitence(Talent)
						player->LearnSpell(53007, false);//Pénitence
					
					player->LearnSpell(48074, false);//Prière d'Esprit
					player->LearnSpell(48162, false);//Prière de robustesse
					//Magie de lombre
					player->LearnSpell(453, false);//Apaisement
					player->LearnSpell(48127, false);//Attaque mentale
					player->LearnSpell(605, false);//Contrôle mental
					
					if(player->HasSpell(15407))//Fouet mental(talent)
						player->LearnSpell(48156, false);//Fouet mental
					
					player->LearnSpell(53023, false);//Incandescence mentale
					player->LearnSpell(48125, false);//Mot de l'ombre : Douleur
					player->LearnSpell(48158, false);//Mot de l'ombre : Mort
					player->LearnSpell(10890, false);//Cri psychique
					player->LearnSpell(34433, false);//Ombrefiel
					player->LearnSpell(586, false);//Oubli
					player->LearnSpell(48300, false);//Peste dévorante
					player->LearnSpell(48072, false);//Prière de soins
					player->LearnSpell(48170, false);//Prière de protection contre l'Ombre
					player->LearnSpell(48169, false);//Protection contre l'Ombre
					
					if(player->HasSpell(34914))//Toucher vampirique(Talent)
						player->LearnSpell(48160, false);//Toucher vampirique
					
					player->LearnSpell(10909, false);//Vision télépathique
					//Sacré
					player->LearnSpell(552, false);//Abolir maladie
					
					if(player->HasSpell(34861))//Cercle de soins(Talent)				
						player->LearnSpell(48089, false);//Cercle de soins
					
					player->LearnSpell(48123, false);//Châtiment
					player->LearnSpell(48135, false);//Flammes sacrées
					player->LearnSpell(528, false);//Guérison des maladies
					player->LearnSpell(64901, false);//Hymne à l'espoir
					player->LearnSpell(64843, false);//Hymne divin
					player->LearnSpell(48078, false);//Nova sacrée
					player->LearnSpell(48113, false);//Prière de guérison
					
					if(player->HasSpell(19236))//Prière du désespoir(Talent)
						player->LearnSpell(48173, false);//Prière du désespoir	
					
					if(player->HasSpell(724))//Puits de lumière(Talent)
						player->LearnSpell(48087, false);//Puits de lumière
					
					player->LearnSpell(48068, false);//Rénovation
					player->LearnSpell(48171, false);//Résurrection
					player->LearnSpell(6064, false);//Soins
					player->LearnSpell(2053, false);//Soins inférieurs	
					player->LearnSpell(48120, false);//Soins de lien
					player->LearnSpell(48071, false);//Soins rapides
					player->LearnSpell(48063, false);//Soins supérieurs
					//Compétences
					player->LearnSpell(227, false);//Bâtons
					player->LearnSpell(1180, false);//Dagues
					player->LearnSpell(198, false);//Masses à une main
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_DEATH_KNIGHT:
					//Givre
					player->LearnSpell(51425, false);//Anéantissement
					player->LearnSpell(45524, false);//Chaînes de glace
					player->LearnSpell(57623, false);//Cor de l'hiver
					
					if(player->HasSpell(49143))//Frappe de givre(Talent)
						player->LearnSpell(55268, false);//Frappe de givre
					
					player->LearnSpell(56815, false);//Frappe runique
					player->LearnSpell(47528, false);//Gel de l'esprit
					player->LearnSpell(3714, false);//Passage de givre
					player->LearnSpell(48263, false);//Présence de givre

					if(player->HasSpell(49184))//Rafale hurlante(Talent)
						player->LearnSpell(51411, false);//Rafale hurlante	
					
					player->LearnSpell(47568, false);//Renforcer l'arme runique
					player->LearnSpell(48792, false);//Robustesse glaciale
					player->LearnSpell(49909, false);//Toucher de glace
					//Impie
					player->LearnSpell(42650, false);//Armée des morts
					player->LearnSpell(48707, false);//Carapace anti-magie
					
					if(player->HasSpell(49158))//Explosion morbide(Talent)
						player->LearnSpell(51328, false);//Explosion morbide
					
					player->LearnSpell(49924, false);//Frappe de mort
					player->LearnSpell(49921, false);//Frappe de peste
					
					if(player->HasSpell(55090))//Frappe du Fléau(Talent)
						player->LearnSpell(55271, false);//Frappe du Fléau
					
					player->LearnSpell(49938, false);//Mort et décomposition
					player->LearnSpell(49576, false);//Poigne de la mort
					player->LearnSpell(50977, false);//Porte de la mort
					player->LearnSpell(48265, false);//Présence impie
					player->LearnSpell(61999, false);//Réanimation d'un allié
					player->LearnSpell(46584, false);//Réanimation morbide
					player->LearnSpell(49895, false);//Voile mortel
					//Sang				
					player->LearnSpell(45529, false);//Drain sanglant
					
					if(player->HasSpell(55050))//Frappe au coeur(Talent)
						player->LearnSpell(55262, false);//Frappe au coeur
					
					player->LearnSpell(49930, false);//Frappe de sang
					player->LearnSpell(49941, false);//Furoncle sanglant
					player->LearnSpell(48743, false);//Pacte mortel
					player->LearnSpell(50842, false);//Pestilence
					
					player->LearnSpell(56222, false);//Sombre ordre
					player->LearnSpell(47476, false);//Strangulation				
					//Compétences
					player->LearnSpell(3127, false);//Parade
					player->LearnSpell(53428, false);//Runeforge
					player->LearnSpell(53331, false);//Rune de Lichemort
					player->LearnSpell(54447, false);//Rune de Brise-sort
					player->LearnSpell(53342, false);//Rune de Fracasse-sort
					player->LearnSpell(54446, false);//Rune de Brise-épée
					player->LearnSpell(53323, false);//Rune de Fracasse-épée
					player->LearnSpell(53344, false);//Rune du Croisé déchu
					player->LearnSpell(70164, false);//Rune de la carapace nérubienne
					player->LearnSpell(62158, false);//Rune de la gargouille peau de pierre					
					player->LearnSpell(48778, false);//Destrier de la mort d'Achérus
					player->LearnSpell(750, false);//Armure en plaques
					player->LearnSpell(200, false);//Armes d'hast
					player->LearnSpell(201, false);//Epées à une main
					player->LearnSpell(202, false);//Epées à deux mains
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(197, false);//Haches à deux mains
					player->LearnSpell(198, false);//Masses à une main
					player->LearnSpell(199, false);//Masses à deux mains
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_SHAMAN:
					//Amélioration
					player->LearnSpell(10399, false);//Arme Croque-roc
					player->LearnSpell(58796, false);//Arme de givre
					player->LearnSpell(58804, false);//Arme Furie-des-vents
					player->LearnSpell(58790, false);//Arme Langue de feu
					player->LearnSpell(49281, false);//Bouclier de foudre
					player->LearnSpell(6196, false);//Double vue
					
					
					if(player->GetTeam() == ALLIANCE)
						player->LearnSpell(32182, false);//Héroïsme					
					else					
						player->LearnSpell(2825, false);//Furie sanguinaire
					
					player->LearnSpell(2645, false);//Loup fantôme
					player->LearnSpell(546, false);//Marche sur l’eau
					player->LearnSpell(556, false);//Rappel astral
					player->LearnSpell(131, false);//Respiration aquatique
					player->LearnSpell(3738, false);//Totem de courroux de l'air
					player->LearnSpell(58643, false);//Totem de force de la terre
					player->LearnSpell(8177, false);//Totem de glèbe
					player->LearnSpell(58753, false);//Totem de peau de pierre
					player->LearnSpell(58749, false);//Totem de résistance à la Nature
					player->LearnSpell(58739, false);//Totem de résistance au Feu
					player->LearnSpell(58745, false);//Totem de résistance au Givre
					player->LearnSpell(2062, false);//Totem élémentaire de terre
					player->LearnSpell(8512, false);//Totem Furie-des-vents
					player->LearnSpell(58656, false);//Totem Langue de feu
					player->LearnSpell(6495, false);//Totem Sentinelle
					//Combat élémentaire
					player->LearnSpell(66843, false);//Appel des ancêtres
					player->LearnSpell(66842, false);//Appel des éléments
					player->LearnSpell(66844, false);//Appel des esprits
					player->LearnSpell(49271, false);//Chaîne d'éclairs	
					player->LearnSpell(57994, false);//Cisaille de vent
					player->LearnSpell(49238, false);//Eclair
					player->LearnSpell(8012, false);//Expiation
					player->LearnSpell(60043, false);//Explosion de lave
					player->LearnSpell(49233, false);//Horion de flammes
					player->LearnSpell(49236, false);//Horion de givre
					player->LearnSpell(49231, false);//Horion de terre
					player->LearnSpell(51514, false);//Maléfice
					player->LearnSpell(61657, false);//Nova de feu	
					
					if(player->HasSpell(51490))//Orage(Talent)				
						player->LearnSpell(59159, false);//Orage
					
					if(player->HasSpell(30706))//Totem de courroux(Talent)
						player->LearnSpell(57722, false);//Totem de courroux

					player->LearnSpell(58582, false);//Totem de griffes de pierre
					player->LearnSpell(2484, false);//Totem de lien terrestre	
					player->LearnSpell(58734, false);//Totem de magma 
					player->LearnSpell(2894, false);//Totem élémentaire de feu
					player->LearnSpell(58704, false);//Totem incendiaire
					//Restauration
					player->LearnSpell(51994, false);//Arme Viveterre
					player->LearnSpell(57960, false);//Bouclier d'eau

					if(player->HasSpell(974))//Bouclier de terre(Talent)
						player->LearnSpell(49284, false);//Bouclier de terre
					
					player->LearnSpell(49277, false);//Esprit ancestral
					player->LearnSpell(526, false);//Guérison des toxines
					player->LearnSpell(36936, false);//Rappel totémique
					player->LearnSpell(20608, false);//Réincarnation					
					
					if(player->HasSpell(61295))//Remous(Talent)
						player->LearnSpell(61301, false);//Remous
					
					player->LearnSpell(55459, false);//Salve de guérison
					player->LearnSpell(8170, false);//Totem de purification	
					player->LearnSpell(8143, false);//Totem de séisme
					player->LearnSpell(58774, false);//Totem Fontaine de mana
					player->LearnSpell(58757, false);//Totem guérisseur
					player->LearnSpell(49273, false);//Vague de soins					
					player->LearnSpell(49276, false);//Vague de soins inférieurs					
					//Compétences
					player->LearnSpell(8737, false);//Mailles
					player->LearnSpell(15590, false);//Armes de pugilat
					player->LearnSpell(227, false);//Bâtons
					player->LearnSpell(1180, false);//Dagues					
					player->LearnSpell(196, false);//Haches à une main
					player->LearnSpell(197, false);//Haches à deux mains
					player->LearnSpell(198, false);//Masses à une main
					player->LearnSpell(199, false);//Masses à deux mains
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();
				break;
				case CLASS_DRUID:
					//Combat farouche
					player->LearnSpell(62078, false);//Balayage (félin)
					player->LearnSpell(48562, false);//Balayage (ours)
					player->LearnSpell(33357, false);//Célérité
					player->LearnSpell(49376, false);//Charge farouche (félin)
					player->LearnSpell(16979, false);//Charge farouche (ours)
					player->LearnSpell(49800, false);//Déchirure
					player->LearnSpell(62600, false);//Défense sauvage
					player->LearnSpell(48575, false);//Dérobade
					player->LearnSpell(5229, false);//Enrager
					player->LearnSpell(49802, false);//Estropier
					player->LearnSpell(1066, false);//Forme aquatique
					player->LearnSpell(5487, false);//Forme d'ours
					player->LearnSpell(9634, false);//Forme d'ours redoutable
					player->LearnSpell(768, false);//Forme de félin
					player->LearnSpell(33943, false);//Forme de vol
					player->LearnSpell(40120, false);//Forme de vol rapide
					player->LearnSpell(783, false);//Forme de voyage
					player->LearnSpell(50213, false);//Fureur du tigre
					player->LearnSpell(20719, false);//Grâce féline
					player->LearnSpell(48570, false);//Griffe
					player->LearnSpell(48574, false);//Griffure
					player->LearnSpell(6795, false);//Grondement	
					player->LearnSpell(48568, false);//Lacérer
					player->LearnSpell(48572, false);//Lambeau
					player->LearnSpell(16857, false);//Lucioles (farouche)
					player->LearnSpell(48577, false);//Morsure féroce
					player->LearnSpell(48564, false);//Mutilation (ours)
					player->LearnSpell(48566, false);//Mutilation (félin)
					player->LearnSpell(48480, false);//Mutiler
					player->LearnSpell(5225, false);//Pistage des humanoïdes
					player->LearnSpell(48579, false);//Ravage
					player->LearnSpell(22842, false);//Régénération frénétique
					player->LearnSpell(5215, false);//Rôder
					player->LearnSpell(48560, false);//Rugissement démoralisant
					player->LearnSpell(5209, false);//Rugissement provocateur
					player->LearnSpell(52610, false);//Rugissement sauvage
					player->LearnSpell(8983, false);//Sonner
					player->LearnSpell(49803, false);//Traquenard
					//Equilibre
					player->LearnSpell(26995, false);//Apaiser les animaux
					player->LearnSpell(48461, false);//Colère	
					player->LearnSpell(33786, false);//Cyclone	
					player->LearnSpell(48463, false);//Eclat lunaire
					player->LearnSpell(22812, false);//Ecorce
					player->LearnSpell(53312, false);//Emprise de la nature
					player->LearnSpell(53307, false);//Epines
					
					if(player->HasSpell(5570))//Essaim d'insectes(Talent)
						player->LearnSpell(48468, false);//Essaim d'insectes
					
					player->LearnSpell(48465, false);//Feu stellaire
					player->LearnSpell(18658, false);//Hibernation
					player->LearnSpell(29166, false);//Innervation
					player->LearnSpell(770, false);//Lucioles
					
					if(player->HasSpell(48505))//Météores(Talent)
						player->LearnSpell(53201, false);//Météores
					
					player->LearnSpell(48467, false);//Ouragan
					player->LearnSpell(53308, false);//Sarments
					player->LearnSpell(18960, false);//Téléportation : Reflet-de-Lune
					
					if(player->HasSpell(50516))//Typhon(Talent)
						player->LearnSpell(61384, false);//Typhon
					
					//Restauration
					player->LearnSpell(2893, false);//Abolir le poison	
					
					if(player->HasSpell(48438))//Croissance sauvage(Talent)
						player->LearnSpell(53251, false);//Croissance sauvage
					
					player->LearnSpell(2782, false);//Délivrance de la malédiction
					player->LearnSpell(48470, false);//Don du fauve
					player->LearnSpell(48451, false);//Fleur de vie
					player->LearnSpell(8946, false);//Guérison du poison	
					player->LearnSpell(48469, false);//Marque du fauve
					player->LearnSpell(50464, false);//Nourrir
					player->LearnSpell(48441, false);//Récupération
					player->LearnSpell(48477, false);//Renaissance
					player->LearnSpell(50763, false);//Ressusciter	
					player->LearnSpell(48443, false);//Rétablissement
					player->LearnSpell(48378, false);//Toucher guérisseur
					player->LearnSpell(48447, false);//Tranquillité
					//Compétences
					player->LearnSpell(200, false);//Armes d'hast;
					player->LearnSpell(15590, false);//Armes de pugilat
					player->LearnSpell(227, false);//Bâtons
					player->LearnSpell(1180, false);//Dagues	
					player->LearnSpell(198, false);//Masses à une main
					player->LearnSpell(199, false);//Masses à deux mains
					player->UpdateWeaponsSkillsToMaxSkillsForLevel();
					player->SaveToDB();	
				break;		
			}	
			return true;
		}
	};
    CreatureAI* GetAI(Creature* creature) const override
    {
        return new npc_skillAI(creature);
    }
};

void AddSC_npc_skill()
{
    new npc_skill();
}