const crypto = require('crypto')
const salt = crypto.randomBytes(32)
