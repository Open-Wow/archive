-- PNJ Gossip 
local NpcId = 32681
local MenuId = 700


-- Gestion file d'attente
local ListeAttente = {}; -- Liste d'attente vide (liste de nom)
local NombreJoueur = 1


-- Fonctions : Inscription & Désinscription
local function inscription(pName)

  local trouve = true

  for numero, nom in pairs(ListeAttente) do -- Parcours liste d'attente
    if (nom == pName) then -- Si il existe déjà ce nom sur la liste
      trouve = false
      break
    end
  end

  if (trouve == true) then 
    table.insert(ListeAttente, pName) -- Inscription dans la liste
  end

  return trouve
end


local function desinscription(pName)

  local trouve = false

  for numero, nom in pairs(ListeAttente) do -- Parcours liste d'attente
    if (nom == pName) then -- Si il est bien dans la liste
      table.remove(ListeAttente, numero) -- Suppression dans la liste
      trouve = true
      break
    end
  end

  return trouve
end

local function evenement()

  if (#ListeAttente == NombreJoueur) then
    for numero, nom in pairs(ListeAttente) do
      for _, player in ipairs(GetPlayersInWorld()) do
        if (player:GetName() == nom) then
          player:Teleport(571, 5804.149902, 624.70996, 647.767029, 1.640000)
        end
      end
    end
    
    ListeAttente = {};
  end
end


-- GOSSIP
local function OnGossipHello(event, player, object)
  player:GossipClearMenu() -- Necessaire pour les joueurs
  player:GossipSetText("Salutations Open-Wow , venez donc vous inscrire à mon super événement !")
  player:GossipMenuAddItem(0, "M'inscrire à l'événement Open-Wow !", 1, 1) -- choix inscription
  player:GossipMenuAddItem(0, "Me désinscrire de l'événement Open-Wow...", 1, 2) -- choix dèsinscription
  player:GossipSendMenu(0x7FFFFFFF, object, MenuId) -- MenuId necessaire pour les joueurs
end

local function OnGossipSelect(event, player, object, sender, intid, code, menuid)
  local pName = player:GetName()
  local pGuid = player:GetGUIDLow()

  if (intid == 1) then
    if (inscription(pName) == true) then
      player:SendNotification("Vous venez d'être inscrit à la file d'attente avec succès !")
      evenement()
     
    else
      player:SendNotification("Vous êtes déjà inscrit à la file d'attente")
    end
    
    OnGossipHello(event, player, object) -- Evite de se retrouver avec un gossip figé

  elseif (intid == 2) then
    if (desinscription(pName) == true) then
      player:SendNotification("Vous n'êtes plus inscrit à la file d'attente")
    else
      player:SendNotification("Vous n'êtes pas inscrit dans la file d'attente")
    end
    OnGossipHello(event, player, object) -- Evite de se retrouver avec un gossip figé
  end
end

RegisterCreatureGossipEvent(NpcId, 1, OnGossipHello)
RegisterCreatureGossipEvent(NpcId, 2, OnGossipSelect)


-- Kazuma