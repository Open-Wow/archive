#include "ScriptMgr.h"
#include "ScriptedGossip.h"
#include "DatabaseEnv.h"
#include "WorldSession.h"

using namespace std;

class Top_10_Arena : public CreatureScript
{
public:
	Top_10_Arena() : CreatureScript("Top_10_Arena") { }

	static bool OnGossipHello(Player* player, Creature * creature)
	{
		AddGossipItemFor(player,GOSSIP_ICON_CHAT, "|TInterface\\icons\\Achievement_arena_2v2_7:30|t Top 10 - Arène 2v2", GOSSIP_SENDER_MAIN, 1);
		AddGossipItemFor(player,GOSSIP_ICON_CHAT, "|TInterface\\icons\\Achievement_arena_3v3_7:30|t Top 10 - Arène 3v3", GOSSIP_SENDER_MAIN, 2);
		AddGossipItemFor(player,GOSSIP_ICON_CHAT, "|TInterface\\icons\\Achievement_arena_5v5_7:30|t Top 10 - Arène 5v5", GOSSIP_SENDER_MAIN, 3);
		SendGossipMenuFor(player,DEFAULT_GOSSIP_MESSAGE, creature->GetGUID());
		return true;
	}

	static bool OnGossipSelect(Player* player, Creature* creature, uint32 action)
	{
		ClearGossipMenuFor(player);
		switch (action)
		{
			case 1: 
			{
				QueryResult result = CharacterDatabase.Query("SELECT name,rating FROM arena_team WHERE type ='2' ORDER BY rating DESC LIMIT 10");
				if (!result)
				{
					player->GetSession()->SendNotification("Malheureusement aucunes statistiques n\'est à montrer.");
					OnGossipHello(player,creature);
					return false;
				}
				Field * fields = NULL;
				AddGossipItemFor(player,GOSSIP_ACTION_INN, "|CFF4E008FNom de l\'Equipe|r // |CFF006C8FCôte de l\'Equipe|r", 1, 1);				
				do
				{
					fields = result->Fetch();
					string name = fields[0].GetString();
					uint32 rating = fields[1].GetUInt32();
					std::ostringstream ss;
					ss << "|CFF4E008F" << name << "|r" << " - |CFF006C8F" << rating << "|r";
					AddGossipItemFor(player,GOSSIP_ICON_BATTLE, ss.str(), GOSSIP_SENDER_MAIN, 1);
				}while (result->NextRow());
				AddGossipItemFor(player,GOSSIP_ICON_INTERACT_2, "< retour >", GOSSIP_SENDER_MAIN, 4);
				SendGossipMenuFor(player, player->GetGossipTextId(creature), creature->GetGUID());					
			}
			break;
			case 2: 
			{
				QueryResult result = CharacterDatabase.Query("SELECT name,rating FROM arena_team WHERE type ='3' ORDER BY rating DESC LIMIT 10");
				if (!result)
				{
					player->GetSession()->SendNotification("Malheureusement aucunes statistiques n\'est à montrer.");
					OnGossipHello(player,creature);
					return false;
				}
				Field * fields = NULL;
				AddGossipItemFor(player,GOSSIP_ACTION_INN, "|CFF4E008FNom de l\'Equipe|r // |CFF006C8FCôte de l\'Equipe|r", 1, 2);
				do
				{
					fields = result->Fetch();
					string name = fields[0].GetString();
					uint32 rating = fields[1].GetUInt32();
					std::ostringstream ss;
					ss << "|CFF4E008F" << name << "|r" << " - |CFF006C8F" << rating << "|r";
					AddGossipItemFor(player,GOSSIP_ICON_BATTLE, ss.str(), GOSSIP_SENDER_MAIN, 2);
				}while (result->NextRow());
				AddGossipItemFor(player,GOSSIP_ICON_INTERACT_2, "< retour >", GOSSIP_SENDER_MAIN, 4);
				SendGossipMenuFor(player, player->GetGossipTextId(creature), creature->GetGUID());
			}
			break;
			case 3: 
			{
				QueryResult result = CharacterDatabase.Query("SELECT name,rating FROM arena_team WHERE type ='5' ORDER BY rating DESC LIMIT 10");
				if (!result)
				{
					player->GetSession()->SendNotification("Malheureusement aucunes statistiques n\'est à montrer.");
					OnGossipHello(player,creature);
					return false;
				}
				Field * fields = NULL;
				AddGossipItemFor(player,7, "|CFF4E008FNom de l\'Equipe|r // |CFF006C8FCôte de l\'Equipe|r", 1, 3);
				do
				{
					fields = result->Fetch();
					string name = fields[0].GetString();
					uint32 rating = fields[1].GetUInt32();
					std::ostringstream ss;
					ss << "|CFF4E008F" << name << "|r" << " - |CFF006C8F" << rating << "|r";
					AddGossipItemFor(player,GOSSIP_ICON_BATTLE, ss.str(), GOSSIP_SENDER_MAIN, 3);
				}while (result->NextRow());
				AddGossipItemFor(player,GOSSIP_ICON_INTERACT_2, "< retour >", GOSSIP_SENDER_MAIN, 4);
				SendGossipMenuFor(player, player->GetGossipTextId(creature), creature->GetGUID());
			}
			break;
			case 4: 
			{
				OnGossipHello(player,creature);
			}
			break;
		}

		return true;
	}
			struct MyAI : public ScriptedAI
		{
			MyAI(Creature* creature) : ScriptedAI(creature) { }
			bool GossipHello(Player* player) override
			{
				return OnGossipHello(player, me);
			}
			bool GossipSelect(Player* player, uint32 menuId, uint32 gossipListId) override
			{
				uint32 action = player->PlayerTalkClass->GetGossipOptionAction(gossipListId);
				return OnGossipSelect(player, me, action);
			}

		};
		CreatureAI* GetAI(Creature* creature) const override
		{
			return new MyAI(creature);
		}
};

void AddSC_Top_10_Arena()
{
	new Top_10_Arena;
}